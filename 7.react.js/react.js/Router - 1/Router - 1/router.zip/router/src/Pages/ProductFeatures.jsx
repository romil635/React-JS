import React from 'react'

const ProductFeatures = () => {
  return (
    <>
      <h1 className='text-2xl font-bold text-center'>This is ProductFetures Page</h1>
    </>
  )
}

export default ProductFeatures
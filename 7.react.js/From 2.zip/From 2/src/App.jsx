import React from 'react'
import SignInSignUp from './Pages/SigninSignUp'
import Home from './Pages/Home'



const App = () => {
  return (
    <>
        <SignInSignUp />
    </>
    
  )
}

export default App
import React from 'react'

import { useNavigate } from 'react-router-dom'
import Navbar from '../Componets/Navbar'

const OrderSummary = () => {

    const navigate1 = useNavigate()

  return (
    <>
       <Navbar/>
      <span className='text-2xl font-bold text-center'>Order Confirmed!!!</span><br></br>
      <button onClick={() => navigate1(-1)}>Go Back</button>
    </>
  )
}

export default OrderSummary
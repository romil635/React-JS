import React from 'react'

const Home = () => {
  return (
    <>
        <h1 className='text-2xl font-bold text-center'>This Is Home Page</h1>    
    </>
  )
}

export default Home

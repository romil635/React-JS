import React from 'react'
import { Link , Outlet } from 'react-router-dom'

const Product = () => {
  return (
    <>
      <h1 className='text-2xl font-bold text-center'>This is Product Page</h1>
      <nav className='mt-6'>
        <Link className='me-5' to='productfeatures'>Product Features</Link>
        <Link to='newproduct'>New Product</Link>
      </nav>
      <Outlet/>
    </>
  )
}

export default Product
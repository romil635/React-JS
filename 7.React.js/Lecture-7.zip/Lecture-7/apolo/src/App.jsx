import './App.css'
import Rendering from './Conditional/Rendering'

/* React Conditional Rendering */



function App() {
  return (
    <>
      <Rendering/>
    </>
  )
}

export default App
